#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time
import math
import numpy as np
import cv2

from std_msgs.msg import Float32MultiArray
from ros_apriltag.msg import ApriltagPosition
from std_msgs.msg import Int8
from std_msgs.msg import Empty

# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from drone_controller import BasicDroneController
from drone_video_display import DroneVideoDisplay

# Finally the GUI libraries
from PyQt5 import QtCore, QtGui, QtWidgets

# Simple PID Controller class
from pid_controller import PID

battrey = 0
altitude = 0

# Here we define the keyboard map for our controller (note that python has no enums, so we use a class)
class KeyMapping(object):
	PitchForward     = QtCore.Qt.Key_W
	PitchBackward    = QtCore.Qt.Key_S
	RollLeft         = QtCore.Qt.Key_A
	RollRight        = QtCore.Qt.Key_D
	YawLeft          = QtCore.Qt.Key_Q
	YawRight         = QtCore.Qt.Key_E
	IncreaseAltitude = QtCore.Qt.Key_I
	DecreaseAltitude = QtCore.Qt.Key_K
	Takeoff          = QtCore.Qt.Key_T
	Land             = QtCore.Qt.Key_Space
	#Emergency       = QtCore.Qt.Key_O
	StartStop        = QtCore.Qt.Key_P
	AutoMode         = QtCore.Qt.Key_O
	Reset            = QtCore.Qt.Key_R
# Our controller definition, note that we extend the DroneVideoDisplay class
class KeyboardController(DroneVideoDisplay):
	def __init__(self):
		super(KeyboardController,self).__init__()
		self.running = False
		rospy.Subscriber('/desired_position_line', Float32MultiArray, self.callback_line_pos)
		rospy.Subscriber('/tello/flight_data/battrey',Int8,self.callback_battrey)
		rospy.Subscriber('/tello/flight_data/altitude',Int8,self.callback_altitude)
		rospy.Subscriber('/tello/video_loss',Empty,self.callback_video_loss)
		self.img = np.zeros((300,512,3), np.uint8)
		cv2.namedWindow('image')
		# create trackbars for color change
		cv2.createTrackbar('PoleP','image',1,700,self.nothing)
		cv2.createTrackbar('PoleR','image',1,700,self.nothing)

		self.controller = BasicDroneController()
	
		self.pitch = 0
		self.roll = 0
		self.yaw_velocity = 0 
		self.z_velocity = 0
		

		self.a = 0
		self.b = 0
		self.flag_roll = True
		self.flag_throttle = True
		self.go = True

		self.pitch_ym_kp1 = 0 
		self.pitch_ym_k = 0
		self.pitch_ym_kn1 = 0
		self.pitch_y_k = 0
		self.pitch_y_kn1 = 0 
		self.pitch_u_k = 0 
		self.pitch_u_kn1 = 0

		self.yaw_ym_kp1 = 0 
		self.yaw_ym_k = 0
		self.yaw_ym_kn1 = 0
		self.yaw_y_k = 320
		self.yaw_y_kn1 = 320 
		self.yaw_u_k = 0 
		self.yaw_u_kn1 = 0	
		
		self.roll_ym_kp1 = 0 
		self.roll_ym_k = 0
		self.roll_ym_kn1 = 0
		self.roll_y_k = 0
		self.roll_y_kn1 = 0 
		self.roll_u_k = 0 
		self.roll_u_kn1 = 0
# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
	def keyPressEvent(self, event):
		key = event.key()
		#print(int(round(time.time() * 1000)))

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():		
			# Handle the important cases first!
			if key == KeyMapping.Land:
				self.controller.SendLand()
			if key == KeyMapping.Reset:
				self.a = 0
				self.b = 0
				self.flag_roll = True
				self.flag_throttle = True
				self.go = True
			elif key == KeyMapping.Takeoff:
				self.controller.SendTakeoff()
				#while (True):
				#	p_z = PID(0.08,0.0,0.0)
				#	p_z.setPoint(11)
				#	print ("altitude : " , altitude)
				#	u_z = p_z.update(altitude)
				#	print ("u_z is :{}".format(u_z))
				#	self.controller.SetCommand(0, 0, 0, u_z)
				#	if abs(u_z<0.09):
				#		break
			#elif key == KeyMapping.Land:
				#self.controller.SendLand()	
			elif self.running is False and key == KeyMapping.AutoMode:
				print('AutoMode ...')
				#self.controller.SendTakeoff()
				self.running = True
				self.flag_roll = True
				self.flag_throttle = True
			elif self.running is False and key == KeyMapping.StartStop:
				print('Starting ...')
				self.running = True
			elif key == KeyMapping.StartStop or key == KeyMapping.AutoMode:
				print('Stopping ...')
				self.running = False

			else:
				# Now we handle moving, notice that this section is the opposite (+=) of the keyrelease section
				if key == KeyMapping.YawLeft:
					self.yaw_velocity += 0.3
				elif key == KeyMapping.YawRight:
					self.yaw_velocity += -0.3

				elif key == KeyMapping.PitchForward:
					self.pitch += 0.3
				elif key == KeyMapping.PitchBackward:
					self.pitch += -0.3

				elif key == KeyMapping.RollLeft:
					self.roll += 0.3
				elif key == KeyMapping.RollRight:
					self.roll += -0.3

				elif key == KeyMapping.IncreaseAltitude:
					self.z_velocity += 0.3
				elif key == KeyMapping.DecreaseAltitude:
					self.z_velocity += -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)
	def callback_altitude(self , msg):
		global altitude
		altitude = msg.data
	def callback_video_loss(self , msg):
		print("loss detected")
		self.controller.SetCommand(0, 0 , 0, 0)
	def callback_battrey(self , msg):
		global battrey
		battrey = msg.data
	def nothing(self , x):
		pass
	def callback_line_pos (self, msg):
		if  self.running:
			if self.flag_roll:
				cv2.imshow('image',self.img)
				
				self.pitch_q = 0.001 #float(cv2.getTrackbarPos('PoleP','image'))/100000
				self.pitch_c1 = -2*self.pitch_q
				self.pitch_c2 = self.pitch_q**2 
				self.pitch_r0 = self.pitch_c1 + 0.1409
				self.pitch_r1 = self.pitch_c2 + 0.5511
				
				self.roll_q = 0.001 #float(cv2.getTrackbarPos('PoleR','image'))/100000
				self.roll_c1 = -2*self.roll_q
				self.roll_c2 = self.roll_q**2 
				self.roll_r0 = self.roll_c1 + 0.5727
				self.roll_r1 = self.roll_c2 + 0.2211
				
				print(self.pitch_q)
				print(self.roll_q)

				self.to = time.time()

				#for pitch 
				self.pitch_y_kp1 = msg.data[2] 
				self.pitch_ym_k = msg.data[3]  
				
				#self.pitch_u_k = (1/0.2946)*(self.pitch_ym_kp1 - 0.002*self.pitch_ym_k + 0.000001*self.pitch_ym_kn1 - 0.0154*self.pitch_u_kn1 - 0.1389*self.pitch_y_k -0.551101*self.pitch_y_kn1) 
				#self.pitch_u_k = (1/0.2946)*(self.pitch_ym_kp1 - self.pitch_ym_k + 0.25*self.pitch_ym_kn1 - 0.0154*self.pitch_u_kn1 - 0.8591*self.pitch_y_k -0.8011*self.pitch_y_kn1) 
				self.pitch_u_k = (1/0.2946)*(self.pitch_ym_kp1 + self.pitch_c1*self.pitch_ym_k + self.pitch_c2*self.pitch_ym_kn1 - 0.0154*self.pitch_u_kn1 - self.pitch_r0*self.pitch_y_k - self.pitch_r1*self.pitch_y_kn1) 

				self.pitch_ym_kn1 = self.pitch_ym_k
				self.pitch_ym_k   = self.pitch_ym_kp1
				self.pitch_u_kn1  = self.pitch_u_k
				self.pitch_y_kn1  = self.pitch_y_k
			
				#for roll 
				self.roll_y_kp1 = msg.data[0] - 320
				self.roll_ym_k = msg.data[1] - 320
				
				#self.roll_u_k = (1/0.3439)*(self.roll_ym_kp1 - 0.002*self.roll_ym_k +0.000001*self.roll_ym_kn1 -0.1356*self.roll_u_kn1 -0.05707*self.roll_y_k -0.221101*self.roll_y_kn1 )
				self.roll_u_k = (1/0.3439)*(self.roll_ym_kp1 + self.roll_c1*self.roll_ym_k + self.roll_c2*self.roll_ym_kn1 - 0.1356*self.roll_u_kn1 - self.roll_r0*self.roll_y_k - self.roll_r1*self.roll_y_kn1)
				self.roll_ym_kn1 = self.roll_ym_k
				self.roll_ym_k   = self.roll_ym_kp1
				self.roll_u_kn1  = self.roll_u_k
				

				#for yaw 
				'''self.yaw_ym_kp1 = math.degrees(math.atan2((msg.data[2] + msg.data[3])-240,(msg.data[0]+msg.data[1])-320))
				
				self.yaw_u_k = 16.8236*self.yaw_ym_kp1 - 0.03364*self.yaw_ym_k + 0.00001682*self.yaw_ym_kn1 + 0.8418*self.yaw_u_kn1 - 26.6991*self.yaw_y_k + 10.0267*self.yaw_y_kn1 
				self.yaw_ym_kn1 = self.yaw_ym_k
				self.yaw_ym_k = self.yaw_ym_kp1
				self.yaw_u_kn1 = self.yaw_u_k'''
				
				p_yaw = PID(0.02,0.0,0.0)
				p_yaw.setPoint(0)
				u_yaw = -p_yaw.update(msg.data[4]) 
				
				
				
				self.k_roll = -3
				self.k_pitch = -1.5

				print("roll_u_k : " , self.roll_u_k/self.k_roll)
				print("pitch_u_k : " , self.pitch_u_k*self.k_pitch)
				print ("u_yaw is :{}".format(u_yaw))
				#print("angle is : " , msg.data[4])
				#print(self.pitch_c1,self.pitch_c2,self.pitch_r0,self.pitch_r1)
				#print(self.roll_c1,self.roll_c2,self.roll_r0,self.roll_r1)
				#print(time.time() - self.to)
				self.controller.SetCommand(0, self.pitch_u_k*self.k_pitch, u_yaw, 0)
				#self.controller.SetCommand(self.roll_u_k/self.k_roll , self.pitch_u_k*self.k_pitch , 0 , 0)
				print("\n")
	def keyReleaseEvent(self,event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():
			# Note that we don't handle the release of emergency/takeoff/landing keys here, there is no need.
			# Now we handle moving, notice that this section is the opposite (-=) of the keypress section
			if key == KeyMapping.YawLeft:
				self.yaw_velocity -= 0.3
			elif key == KeyMapping.YawRight:
				self.yaw_velocity -= -0.3

			elif key == KeyMapping.PitchForward:
				self.pitch -= 0.3
			elif key == KeyMapping.PitchBackward:
				self.pitch -= -0.3

			elif key == KeyMapping.RollLeft:
				self.roll -= 0.3
			elif key == KeyMapping.RollRight:
				self.roll -= -0.3

			elif key == KeyMapping.IncreaseAltitude:
				self.z_velocity -= 0.3
			elif key == KeyMapping.DecreaseAltitude:
				self.z_velocity -= -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)



# Setup the application
if __name__=='__main__':
	import sys
	# Firstly we setup a ros node, so that we can communicate with the other packages
	rospy.init_node('behavior_unified_controller',anonymous=True, disable_signals=True)

	# Now we construct our Qt Application and associated controllers and windows
	app = QtWidgets.QApplication(sys.argv)
	display = KeyboardController()

	display.show()

	# executes the QT application
	status = app.exec_()

	# and only progresses to here once the application has been shutdown
	rospy.signal_shutdown('Great Flying!')
	sys.exit(status)


