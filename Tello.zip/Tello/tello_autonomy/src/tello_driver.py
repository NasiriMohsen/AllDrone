#!/usr/bin/env python

import rospy
import roslib

from sensor_msgs.msg import Image

# Import the messages we're interested in sending and receiving
from geometry_msgs.msg import Twist  	 # for sending commands to the drone
from std_msgs.msg import Empty       	 # for land/takeoff/flip
from std_msgs.msg import Int8

import cv2
from cv_bridge import CvBridge, CvBridgeError

import sys
import traceback
import tellopy
import av
import numpy
import time

prev_flight_data = None


class TelloDriver(object):
    def __init__(self):
        ImageRaw = rospy.Publisher('/tello/image_raw',Image, queue_size=10)
        self.FlightData_Battrey = rospy.Publisher('/tello/flight_data/battrey',Int8,queue_size=10)
        self.FlightData_Altitude = rospy.Publisher('/tello/flight_data/altitude',Int8,queue_size=10)
        Video_Loss = rospy.Publisher('/tello/video_loss',Empty,queue_size=10)

        rospy.Subscriber('/tello/takeoff', Empty, self.callback_takeoff)
        rospy.Subscriber('/tello/land', Empty, self.callback_land)
        rospy.Subscriber('/tello/pose_x',Int8,self.callback_pose_x)

        rospy.Subscriber('/tello/cmd_vel', Twist, self.callback_cmd_vel)

        #self.rate = rospy.Rate(10)
        #print( help('tellopy'))
        
        global drone
        drone = tellopy.Tello()
        
        try:
            drone.connect()
            drone.wait_for_connection(60.0)
            drone.subscribe(drone.EVENT_FLIGHT_DATA, self.flightDataHandler)
            retry = 3
            container = None
            while container is None and 0 < retry:
                retry -= 1
                try:
                    container = av.open(drone.get_video_stream())
                except av.AVError as ave:
                    print(ave)
                    print('retry...')

            # skip first 300 frames
            frame_skip = 300
            while True:
                #self.rate.sleep()
                try :
                    for frame in container.decode(video=0):
                        if 0 < frame_skip:
                            frame_skip = frame_skip - 1
                            continue
                        start_time = time.time()
                        image = numpy.array(frame.to_image())#cv2.cvtColor(numpy.array(frame.to_image()), cv2.COLOR_RGB2BGR)
                        height, width = 480 , 640
                        resize_image = cv2.resize(image,(width, height), interpolation = cv2.INTER_CUBIC)
                        bridge=CvBridge()
                        #print(drone.loss_data())
                        if drone.loss_data() is not 0 :
                            #print("loss")
                            Video_Loss.publish(Empty())
                        try:
                            image_message = bridge.cv2_to_imgmsg(resize_image, 'bgr8')
                            ImageRaw.publish(image_message)
                        except CvBridgeError as e:
                            print (e)
                        #rospy.loginfo("Publishing Image")
                        if frame.time_base < 1.0/60:
                            time_base = 1.0/60
                        else:
                            time_base = frame.time_base
                        frame_skip = int((time.time() - start_time)/time_base)
                except :
                    pass
                        
        except Exception as ex:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exception(exc_type, exc_value, exc_traceback)
            print(ex)
        finally:
            drone.quit()     
    def flightDataHandler(self,event, sender, data):
        #print('data= {}'.format(data))
        global prev_flight_data
        altitude = 0
        battrey = 0
        text = str(data)

        end = text.find('|',text.find('B')+4,text.find('W'))
        start = text.find('B')+4
        battrey = int(text[start:end])

        end1 = text.find('|',text.find('A'),text.find('S'))
        start1 = text.find('A')+4
        altitude = int(text[start1:end1])

        #print'H : ' , altitude , 'BAT:' , battrey
        #print 'H : {0} BAT : {1}'.format(altitude,battrey)

        if prev_flight_data != text:
            prev_flight_data = text
        
        self.FlightData_Altitude.publish(altitude)
        self.FlightData_Battrey.publish(battrey)


    def callback_takeoff(self,msg):
        drone.takeoff()
    
    def callback_land(self,msg):
        drone.land()   

    def callback_cmd_vel(self, msg):
        #print(msg.linear.z)
        drone.set_pitch(msg.linear.x)
        #pos right
        drone.set_roll(msg.linear.y)
        #pos forward
        drone.set_yaw(msg.angular.z)
        #pos up
        drone.set_throttle(msg.linear.z)
    
    def callback_pose_x(self, msg):
        #print("forward:{}".format(msg.data))
        drone.forward(msg.data)
        


if __name__ == '__main__':
    rospy.init_node('drone_publisher',anonymous=True, disable_signals=True)
    connect = TelloDriver()
