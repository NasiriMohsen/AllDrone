#!/usr/bin/env python

import rospy
import roslib
from copy import copy
from math import degrees , atan2
import cv2
import numpy as np
import sys

from std_msgs.msg import Float32MultiArray
from std_msgs.msg import Int8
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image

class SubFrame:
    def __init__(self,frame,HSV,name):  
        self.name = name  
        self.frame = frame 
        self.hsv = cv2.cvtColor(self.frame, cv2.COLOR_BGR2LAB)
        self.gray= cv2.cvtColor(self.frame, cv2.COLOR_BGR2GRAY)
        self.lower_blue = np.array([HSV[0], HSV[1] ,HSV[2]])
        self.upper_blue = np.array([HSV[3], HSV[4], HSV[5]])
        self.w , self.h , self.x , self.y = 0 , 0 , 0 , 0
        #self.mask =cv2.adaptiveThreshold(self.gray , 255 , cv2.ADAPTIVE_THRESH_GAUSSIAN_C , 
        #cv2.THRESH_BINARY_INV , 149,38) 
        self.mask = cv2.inRange(self.hsv, self.lower_blue, self.upper_blue)
        '''self.kernel = np.ones((5,5),np.uint8)
        self.dilation = cv2.dilate(self.mask,self.kernel,iterations = 2)
        self.kernel = np.ones((15,15),np.uint8)
        self.opening = cv2.morphologyEx(self.dilation, cv2.MORPH_OPEN, self.kernel)
        self.mask = cv2.morphologyEx(self.opening, cv2.MORPH_CLOSE, self.kernel)'''
        self.res = cv2.bitwise_and(self.frame,self.frame, mask= self.mask)
        _ ,self.contours, _ = cv2.findContours(self.mask, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        if len(self.contours) > 0:
            cnt = max(self.contours, key = cv2.contourArea)
            try:
                M = cv2.moments(cnt) 
                cx = int(M['m10']/M['m00'])
                cy = int(M['m01']/M['m00'])
                self.x,self.y,self.w,self.h = cv2.boundingRect(cnt)
                self.frame = cv2.rectangle(self.frame,(self.x,self.y),(self.x+self.w,self.y+self.h),(0,255,0),2)
                cv2.circle(self.frame,(self.x+self.w/4,self.y+self.h/2), 12, (0,0,255), -1)
                cv2.circle(self.frame,(640/2,480/2), 12, (0,255,0), -1)
                #cv2.circle(self.frame,(640/4,400/2), 12, (0,125,125), -1)
            except:
                pass
        cv2.waitKey(1) 
        #cv2.imshow("Frame" + self.name , self.res)
        #cv2.imshow("frame" + self.name , self.frame)   
    def CentreOfCircle(self):
        return self.x , self.w , self.y , self.h 
    def ContourArea(self):
        return self.x + self.w/2 ,self.y + self.h/2

def Init(data): 
    #rospy.loginfo('recieve image')
    bridge = CvBridge()
    xb , yb = 0 , 0 
    xd , yd = 0 , 0

    cv_image = bridge.imgmsg_to_cv2(data, "rgb8")
    
    
    
    HSVLine = [0, 0, 0, 69, 255, 255]
    cv_image = cv_image[ 0:240 , 0 :640 ]
    
    cv_image = cv2.flip(cv_image , flipCode=0)
    Line = SubFrame(cv_image , HSVLine , "Line")
    
    cv_image_top = copy(cv_image[ 0:50 , 0 :640 ])
    cv_image_bottom = copy(cv_image[ 190:240 , 0 :640 ])
    
    cv_image_left = copy(cv_image[ 0:240 , 0 :50 ])
    cv_image_right = copy(cv_image[ 0:240 , 590 :640 ])
    
    LineT = SubFrame(cv_image_top , HSVLine , "LineT")
    LineB = SubFrame(cv_image_bottom , HSVLine , "LineB")
    LineR = SubFrame(cv_image_right , HSVLine , "LineR")
    LineL = SubFrame(cv_image_left , HSVLine , "LineL")
    
    
    angle = 0
    if  not(np.array_equal(LineT.ContourArea(),[0,0])):
        #print("front")
        cv2.line(cv_image,(LineB.ContourArea()[0],LineB.ContourArea()[1]+190),LineT.ContourArea(),(255,255,0),5) 
        #angle  = degrees(atan2(240-LineT.ContourArea()[1],LineT.ContourArea()[0]-320))
        angle  = degrees(atan2(240-LineT.ContourArea()[1],LineT.ContourArea()[0]-LineB.ContourArea()[0]))
        xd , yd = LineT.ContourArea()[0] , LineT.ContourArea()[1]
    elif not(np.array_equal(LineR.ContourArea(),[0,0])):
        #print("Right")
        cv2.line(cv_image,(LineB.ContourArea()[0],LineB.ContourArea()[1]+190),(LineR.ContourArea()[0]+590,LineR.ContourArea()[1]),(255,255,0),5) 
        angle  = degrees(atan2(240-LineR.ContourArea()[1],LineR.ContourArea()[0]+590-LineB.ContourArea()[0]))
        if LineR.ContourArea()[1] > 120:
            xd , yd = LineR.ContourArea()[0] + 590 , LineR.ContourArea()[1]
    elif not(np.array_equal(LineL.ContourArea(),[0,0])):
        #print("LEft")
        cv2.line(cv_image,(LineB.ContourArea()[0],LineB.ContourArea()[1]+190),(LineL.ContourArea()[0],LineL.ContourArea()[1]),(255,255,0),5) 
        angle  = degrees(atan2(240-LineL.ContourArea()[1],LineL.ContourArea()[0]-LineB.ContourArea()[0]))
        if LineL.ContourArea()[1] > 120:
            xd , yd = LineL.ContourArea()[0]  , LineL.ContourArea()[1]
    else:
        cv2.line(cv_image,(LineB.ContourArea()[0],LineB.ContourArea()[1]+190),Line.ContourArea(),(255,255,0),5) 
        angle  = degrees(atan2(240-Line.ContourArea()[1],Line.ContourArea()[0]-LineB.ContourArea()[0]))
        xd , yd = Line.ContourArea()[0] , Line.ContourArea()[1]
    angle = 90 - angle
    #print(angle)
    
    cv2.imshow("image",cv_image)
    msg_Line = Float32MultiArray()


    
    
    #msg_Line.data = [Line.CentreOfCircle()[0] , Line.CentreOfCircle()[1] ,
    #Line.CentreOfCircle()[2] , Line.CentreOfCircle()[3] , angle ]
    msg_Line.data = [LineB.ContourArea()[0] , xd , LineB.ContourArea()[1] , yd , angle]

    Desired_Position_Line.publish(msg_Line)


if __name__=='__main__':
    rospy.init_node('cv_camera',anonymous=True, disable_signals=True)
    rospy.loginfo('init ...')

    Desired_Position_Line = rospy.Publisher('/desired_position_line',Float32MultiArray, queue_size=10)
 
    subVideo = rospy.Subscriber('/tello/image_raw', Image , Init )
    
    rospy.spin()