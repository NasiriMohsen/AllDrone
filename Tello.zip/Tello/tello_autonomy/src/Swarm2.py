#!/usr/bin/env python 
import socket
import time 
import rospy

rospy.init_node('Swarm2',anonymous=True, disable_signals=True)

sock2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock2.setsockopt(socket.SOL_SOCKET, 25, 'wlx502b73c8c322'.encode())


sock2.sendto('command'.encode(), 0, ('192.168.10.1', 8889))


sock2.sendto('takeoff'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(8)

sock2.sendto('go 100 0 0 80'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('cw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('cw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('cw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('cw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(8)


sock2.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(6)

sock2.sendto('flip r'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock2.sendto('land'.encode(), 0, ('192.168.10.1', 8889))
