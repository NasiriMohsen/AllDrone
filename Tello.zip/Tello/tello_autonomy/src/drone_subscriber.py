#!/usr/bin/env python

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy

import tellopy

# Import the messages we're interested in sending and receiving
from geometry_msgs.msg import Twist  	 # for sending commands to the drone
from std_msgs.msg import Empty       	 # for land/takeoff/flip
from std_msgs.msg import UInt8

class DroneSubscriber(object):
    def __init__(self):

        drone1 = tellopy.Tello()
        rospy.Subscriber('/tello/takeoff', Empty, self.callback_takeoff)
        rospy.Subscriber('/tello/land', Empty, self.callback_land)


    def callback_takeoff(self):
        drone1.takeoff()
    
    def callback_land(self):
        drone1.land()


if __name__ == '__main__':
    
    rospy.init_node('drone_subscriber',anonymous=True, disable_signals=True)
    init = DroneSubscriber()