import csv
import socket
from time import sleep , time


if __name__ == "__main__":
    data_file = open('speeddatayaw.csv', mode='a')
    data_writer = csv.writer(data_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

    vgx = 0 
    local_ip = ''
    local_port = 8890
    socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # socket for sending cmd
    socket.bind((local_ip, local_port))

    tello_ip = '192.168.10.1'
    tello_port = 8889
    tello_adderss = (tello_ip, tello_port)
    speed = '100'
    socket.sendto('command'.encode('utf-8'), tello_adderss)
    sleep(1)
    socket.sendto('takeoff'.encode('utf-8'), tello_adderss)
    sleep(5)
    socket.sendto('speed 100'.encode('utf-8'), tello_adderss)
    sleep(4)
    socket.sendto('cw 3600'.encode('utf-8'), tello_adderss)
    T0 = time()
    #socket.sendto('speed 100'.encode('utf-8'), tello_adderss)
    last_yaw = 0 
    yaw = 0 
    index = 0 
    while True:
        try:
            last_yaw = yaw
            T1 = time()
            index += 1
            response, ip = socket.recvfrom(1024)
            #if response == 'ok':
            #    continue
            #print(response)
            try : 
                yaw = int(response[response.find('yaw')+4 :response.find('vgx')-1])
                #vgy = int(response[response.find('vgy')+4 :response.find('vgz')-1])
                #data_writer.writerow([speed,str(vgy)])
                #print(vgy)
                #vgz = int(response[response.find('vgz')+4 :response.find('temp')-1])
                pass
            except Exception as e:
                print(e)
                print("shhh")
                pass
            if vgx != 0 :
                #print(vgx,vgy,vgz)
                #print(vgy)
                print("shh")
                #data_writer.writerow([speed,str(vgy)])           
            #sleep(0.01)
            delta_t = time() - T1
            print("TIME : " , delta_t)
            print("Yaw vel : " , delta_t*(yaw-last_yaw))
        except KeyboardInterrupt:
            socket.sendto('land'.encode('utf-8'), tello_adderss)
            break
        except Exception as e :
            print(e)   
    data_file.close()