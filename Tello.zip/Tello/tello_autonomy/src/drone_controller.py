#!/usr/bin/env python

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy

# Import the messages we're interested in sending and receiving
from geometry_msgs.msg import Twist  	 # for sending commands to the drone
from std_msgs.msg import Empty       	 # for land/takeoff/flip
from std_msgs.msg import Int8

# Some Constants
COMMAND_PERIOD = 100 #ms


class BasicDroneController(object):
	def __init__(self):
		# Holds the current drone status
		self.status = -1

		# Allow the controller to publish to the /tello/takeoff land and flip topics
		self.pubLand    = rospy.Publisher('/tello/land', Empty, queue_size=1)
		self.pubTakeoff = rospy.Publisher('/tello/takeoff', Empty, queue_size=1)
		self.pubThrowTakeoff = rospy.Publisher('/tello/throw_takeoff', Empty, queue_size=1)
		self.pubPalmLand = rospy.Publisher('/tello/palm_land', Empty, queue_size=1)
		self.pubFlip = rospy.Publisher('/tello/flip', Int8, queue_size=1)
		
		# Allow the controller to publish to the /cmd_vel topic and thus control the drone
		self.pubCommand = rospy.Publisher('/tello/cmd_vel', Twist, queue_size=1)

		self.pubPoseX = rospy.Publisher('/tello/pose_x',Int8,queue_size=10)

		# Setup regular publishing of control packets
		self.command = Twist()
		self.commandTimer = rospy.Timer(rospy.Duration(COMMAND_PERIOD/1000.0),self.SendCommand)

		# Land the drone if we are shutting down
		rospy.on_shutdown(self.SendLand)


	def SendTakeoff(self):
		# Send a takeoff message
		self.pubTakeoff.publish(Empty())

	def SendLand(self):
		# Send a landing message
		self.pubLand.publish(Empty())

	def SendThrowTakeoff(self):
    	# Send a Throw TakeOff message
		self.pubThrowTakeoff.publish(Empty())

	def SendPalmLand(self):
		# Send a Palm Land message
		self.pubPalmLand.publish(Empty())
	
	def SetPosition(self,posex):
    		self.pubPoseX.publish(posex)

	def SetCommand(self, roll=0, pitch=0, yaw_velocity=0, z_velocity=0):
		# Called by the main program to set the current command
		self.command.linear.x  = pitch
		print(self.command.linear.x)
		self.command.linear.y  = roll
		print(self.command.linear.y)
		self.command.linear.z  = z_velocity
		self.command.angular.z = yaw_velocity
		print('--------')

	def SendCommand(self,event):
		# The previously set command is then sent out periodically if the drone is flying
		self.pubCommand.publish(self.command)
