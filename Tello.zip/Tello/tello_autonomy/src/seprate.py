import csv

csv_file = open('speeddata.csv','r')
csv_reader = csv.reader(csv_file, delimiter=',')
u = []
y = []
for lines in csv_reader:
    u.append(lines[0])
    y.append(lines[1])
a = [ [],[],[],[],[]]
cnt = 0
last = u[0]

for i in range(len(u)):
    if u[i] == last :
        a[cnt].append(y[i])
    else :
        last = u[i]
        cnt += 1
        a[cnt].append(y[i])
for i in range(len(a)):
    print(len(a[i]))