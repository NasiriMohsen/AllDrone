#!/usr/bin/env python 
import socket
import time 
import rospy

rospy.init_node('Swarm1',anonymous=True, disable_signals=True)


sock1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock1.setsockopt(socket.SOL_SOCKET, 25, 'wlp5s0'.encode())


sock1.sendto('command'.encode(), 0, ('192.168.10.1', 8889))


sock1.sendto('takeoff'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(8)

sock1.sendto('go 100 0 0 80'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('ccw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('ccw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('ccw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('ccw 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(8)


sock1.sendto('go 100 0 0 90'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(6)

sock1.sendto('flip l'.encode(), 0, ('192.168.10.1', 8889))
time.sleep(4)

sock1.sendto('land'.encode(), 0, ('192.168.10.1', 8889))
