#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time

from ros_apriltag.msg import ApriltagPosition
from std_msgs.msg import Int8
from std_msgs.msg import Empty

# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from drone_controller import BasicDroneController
from drone_video_display import DroneVideoDisplay

# Finally the GUI libraries
from PyQt5 import QtCore, QtGui, QtWidgets

# Simple PID Controller class
from pid_controller import PID

battrey = 0
altitude = 0

# Here we define the keyboard map for our controller (note that python has no enums, so we use a class)
class KeyMapping(object):
	PitchForward     = QtCore.Qt.Key_W
	PitchBackward    = QtCore.Qt.Key_S
	RollLeft         = QtCore.Qt.Key_A
	RollRight        = QtCore.Qt.Key_D
	YawLeft          = QtCore.Qt.Key_Q
	YawRight         = QtCore.Qt.Key_E
	IncreaseAltitude = QtCore.Qt.Key_I
	DecreaseAltitude = QtCore.Qt.Key_K
	Takeoff          = QtCore.Qt.Key_T
	Land             = QtCore.Qt.Key_Space
	#Emergency        = QtCore.Qt.Key_O
	StartStop        = QtCore.Qt.Key_P
	AutoMode         = QtCore.Qt.Key_O
# Our controller definition, note that we extend the DroneVideoDisplay class
class KeyboardController(DroneVideoDisplay):
	def __init__(self):
		super(KeyboardController,self).__init__()
		rospy.Subscriber('/apriltag', ApriltagPosition, self.callback_apriltag_position)
		rospy.Subscriber('/tello/flight_data/battrey',Int8,self.callback_battrey)
		rospy.Subscriber('/tello/flight_data/altitude',Int8,self.callback_altitude)
		rospy.Subscriber('/apriltag/no',Empty,self.callback_no_apriltag)
		self.controller = BasicDroneController()
		
		self.pitch = 0
		self.roll = 0
		self.yaw_velocity = 0 
		self.z_velocity = 0
		self.id_counter = 0
		self.running = False
		self.ID_NOW = 0
# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
	def keyPressEvent(self, event):
		key = event.key()
		#print(int(round(time.time() * 1000)))

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():		
			# Handle the important cases first!
			if key == KeyMapping.Land:
				self.controller.SendLand()
			elif key == KeyMapping.Takeoff:
				self.controller.SendTakeoff()
				while (True):
					p_z = PID(0.08,0.0,0.0)
					p_z.setPoint(11)
					print ("altitude : " , altitude)
					u_z = p_z.update(altitude)
					print ("u_z is :{}".format(u_z))
					self.controller.SetCommand(0, 0, 0, u_z)
					if abs(u_z<0.09):
						break
			#elif key == KeyMapping.Land:
				#self.controller.SendLand()	
			elif self.running is False and key == KeyMapping.AutoMode:
				print('AutoMode ...')
				self.controller.SendTakeoff()
				#self.running = True
				self.id_counter = 0
			elif self.running is False and key == KeyMapping.StartStop:
				print('Starting ...')
				self.running = True
			elif key == KeyMapping.StartStop or key == KeyMapping.AutoMode:
				print('Stopping ...')
				self.running = False

			else:
				# Now we handle moving, notice that this section is the opposite (+=) of the keyrelease section
				if key == KeyMapping.YawLeft:
					self.yaw_velocity += 0.3
				elif key == KeyMapping.YawRight:
					self.yaw_velocity += -0.3

				elif key == KeyMapping.PitchForward:
					self.pitch += 0.3
				elif key == KeyMapping.PitchBackward:
					self.pitch += -0.3

				elif key == KeyMapping.RollLeft:
					self.roll += 0.3
				elif key == KeyMapping.RollRight:
					self.roll += -0.3

				elif key == KeyMapping.IncreaseAltitude:
					self.z_velocity += 0.3
				elif key == KeyMapping.DecreaseAltitude:
					self.z_velocity += -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)
	def callback_altitude(self , msg):
		global altitude
		altitude = msg.data
	
	def callback_battrey(self , msg):
		global battrey
		battrey = msg.data
	
	def callback_no_apriltag(self , msg):
		#self.contr oller.SetPosition(20)
		if self.running is True:
			self.controller.SetCommand(0, 0.5, 0, 0)
		pass

	def callback_apriltag_position (self, msg):
		apriltag_ID = msg.apriltag_ID
		#Height drone
		if self.running is True and apriltag_ID == self.ID_NOW :
			apriltag_position_x = msg.apriltag_position_x
			apriltag_position_y = msg.apriltag_position_y
			apriltag_position_z = msg.apriltag_position_z
			apriltag_angle = msg.apriltag_angle
			p_x = PID(-0.08,0.0,0.0)
			p_x.setPoint(-2.2)
			u_x = p_x.update(apriltag_position_x) 
			print ("u_x is :{}".format(u_x))
			#self.controller.SetCommand(u_x, 0, 0, 0)
			#height apriltag
			#y direction of Apriltag is equal to z direction of controller
			p_y = PID(0.08,0.0,0.0)
			p_y.setPoint(-0.6)				
			u_y = p_y.update(apriltag_position_y) 
			'''if u_y > 0.6 :
				u_y = 0.6
			elif u_y < -0.6 :
				u_y = -0.6
			if u_x > 0.6 :
				u_x = 0.6
			elif u_x < -0.6 :
				u_x = -0.6'''
			
			print ("u_y is :{}".format(u_y))
			self.controller.SetCommand(u_x, 0, 0, u_y)
			if abs(u_y) < 0.09 and abs(u_x) < 0.09 :
				p_z = PID(-0.01,0.0,0.0)
				p_z.setPoint(40)
				u_z = p_z.update(apriltag_position_z) 
				if u_z > 0.5 :
					u_z = 0.5
				elif u_z < -0.5 :
					u_z = -0.5
				print ("u_z is :{}".format(u_z))
				self.controller.SetCommand(0, u_z, 0, 0)
				print('april tag pos z ::::::::' , apriltag_position_z)
				if abs(apriltag_position_z) < 100 :
					self.controller.SetPosition(100)
					self.ID_NOW = self.ID_NOW + 1
					if altitude < 6 :
						self.controller.SetCommand(0, 0, 0, 0.3)
					if altitude > 8 :
						self.controller.SetCommand(0, 0, 0, -0.3)
					print('ID_NOW:-------------------------- ' , self.ID_NOW)
					
					
			#forward drone
    		#self.controller.SetPosition(50)
			#self.controller.SetCommand(0.0, 0, 0.0, 0.0)
			#angle yaw control
			'''p_a = PID(-0.006,0.0,0.0)
			p_a.setPoint(0)
			u_a = p_x.update(apriltag_angle)
			print("angle : {}".format(apriltag_angle))
			print ("u_x is :{}".format(u_a))
			self.controller.SetCommand(0, 0, u_a, 0)'''
			#left and right 
			
	def keyReleaseEvent(self,event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():
			# Note that we don't handle the release of emergency/takeoff/landing keys here, there is no need.
			# Now we handle moving, notice that this section is the opposite (-=) of the keypress section
			if key == KeyMapping.YawLeft:
				self.yaw_velocity -= 0.3
			elif key == KeyMapping.YawRight:
				self.yaw_velocity -= -0.3

			elif key == KeyMapping.PitchForward:
				self.pitch -= 0.3
			elif key == KeyMapping.PitchBackward:
				self.pitch -= -0.3

			elif key == KeyMapping.RollLeft:
				self.roll -= 0.3
			elif key == KeyMapping.RollRight:
				self.roll -= -0.3

			elif key == KeyMapping.IncreaseAltitude:
				self.z_velocity -= 0.3
			elif key == KeyMapping.DecreaseAltitude:
				self.z_velocity -= -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)



# Setup the application
if __name__=='__main__':
	import sys
	# Firstly we setup a ros node, so that we can communicate with the other packages
	rospy.init_node('behavior',anonymous=True, disable_signals=True)

	# Now we construct our Qt Application and associated controllers and windows
	app = QtWidgets.QApplication(sys.argv)
	display = KeyboardController()

	display.show()

	# executes the QT application
	status = app.exec_()

	# and only progresses to here once the application has been shutdown
	rospy.signal_shutdown('Great Flying!')
	sys.exit(status)


