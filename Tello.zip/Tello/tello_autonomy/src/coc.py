#!/usr/bin/env python

import rospy
import roslib

import cv2
import numpy as np
import sys

from std_msgs.msg import Float32MultiArray
from std_msgs.msg import Int8
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image

class SubFrame:
    def __init__(self,frame,HSV,name):  
        self.name = name  
        self.frame = frame 
        self.hsv = cv2.cvtColor(self.frame, cv2.COLOR_BGR2HSV)
        self.lower_blue = np.array([HSV[0], HSV[1] ,HSV[2]])
        self.upper_blue = np.array([HSV[3], HSV[4], HSV[5]])
        self.w , self.h , self.x , self.y = 0 , 0 , 0 , 0 
        self.mask = cv2.inRange(self.hsv, self.lower_blue, self.upper_blue)
        '''self.kernel = np.ones((5,5),np.uint8)
        self.dilation = cv2.dilate(self.mask,self.kernel,iterations = 2)
        self.kernel = np.ones((15,15),np.uint8)
        self.opening = cv2.morphologyEx(self.dilation, cv2.MORPH_OPEN, self.kernel)
        self.mask = cv2.morphologyEx(self.opening, cv2.MORPH_CLOSE, self.kernel)'''
        self.res = cv2.bitwise_and(self.frame,self.frame, mask= self.mask)
        _ ,self.contours, _ = cv2.findContours(self.mask, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        if len(self.contours) > 0:
            cnt = max(self.contours, key = cv2.contourArea)
            try:
                M = cv2.moments(cnt) 
                cx = int(M['m10']/M['m00'])
                cy = int(M['m01']/M['m00'])
                self.x,self.y,self.w,self.h = cv2.boundingRect(cnt)
                self.frame = cv2.rectangle(self.frame,(self.x,self.y),(self.x+self.w,self.y+self.h),(0,255,0),2)
                cv2.circle(self.frame,(self.x+self.w/4,self.y+self.h/2), 12, (0,0,255), -1)
                cv2.circle(self.frame,(640/2,480/2), 12, (0,255,0), -1)
                #cv2.circle(self.frame,(640/4,400/2), 12, (0,125,125), -1)
            except:
                print('eror')
        cv2.waitKey(1) 
        #cv2.imshow("Frame" + self.name , self.res)
        #cv2.imshow("frame" + self.name , self.frame)   
    def CentreOfCircle(self):
        return self.x , self.w , self.y , self.h 
    def ContourArea(self):
        return self.w*self.h

def Init(data): 
    rospy.loginfo('recieve image')
    bridge = CvBridge()

    cv_image = bridge.imgmsg_to_cv2(data, "rgb8")
    #cv_image2 = cv_image.copy()
    #print(cv_image.shape)
    #Blue Logitech
    #HSVGATE = [91, 89, 0, 98, 209, 255]
    #Green Logitech
    #HSVROTRAY = [40, 88, 0, 57, 118, 255]
    
    #Blue tello
    HSVGATE = [89, 97, 0, 113, 183, 255]
    #Green tello
    HSVROTRAY = [51, 85, 159, 67, 148, 255]
    #magenta box
    #HSVBOX = [160, 112, 0, 207, 166, 255]
    #HSVBOX = [25, 233, 80, 44, 255, 255]
    HSVLine = [ 0 , 0 , 0 , 255 , 255 , 100]

    #Gate = SubFrame(cv_image,HSVGATE,'gate')
    #Rotray = SubFrame(cv_image2,HSVROTRAY,'rotray')
    #Box = SubFrame(cv_image,HSVBOX,'box')
    cv_image = cv_image[ 0:240 , 0 :640 ]
    Line = SubFrame(cv_image , HSVLine , "Line")
    cv_image2 = cv_image[Line.CentreOfCircle()[0]+Line.CentreOfCircle()[1],
    Line.CentreOfCircle()[2] + Line.CentreOfCircle()[3]]
    Line2 = SubFrame(cv_image2 , HSVLine , "Line2")
    
    cv2.imshow("hhh",cv_image)
    msg_gate = Float32MultiArray()
    #msg_rotray = Float32MultiArray()
    
    '''
    msg_gate.data = [ Gate.CentreOfCircle()[0] + Gate.CentreOfCircle()[1]/4 , 
    Gate.CentreOfCircle()[2] + Gate.CentreOfCircle()[3]/2 ,
    Rotray.CentreOfCircle()[1] ,
    Rotray.CentreOfCircle()[3] ,
    Gate.CentreOfCircle()[1]*Gate.CentreOfCircle()[3]]
    '''
    
    #msg_gate.data = [Box.CentreOfCircle()[0] + Box.CentreOfCircle()[1]/2 , 
    #Box.CentreOfCircle()[2] + Box.CentreOfCircle()[3]/2]
    msg_gate.data = [Line.CentreOfCircle()[0] , Line.CentreOfCircle()[1] ,
    Line.CentreOfCircle()[2] , Line.CentreOfCircle()[3] ]
    #msg_rotray.data = [Rotray.CentreOfCircle()[0] + Rotray.CentreOfCircle()[1]/2 ,
    #Rotray.CentreOfCircle()[2] + Rotray.CentreOfCircle()[3]/2 ]
    
    Desired_Position_Gate.publish(msg_gate)
    #Desired_Position_Rotray.publish(msg_rotray)
    
    #print("Area  G :{0} -- Area B : {1}".format(Rotray.CentreOfCircle()[1]*Rotray.CentreOfCircle()[3] ,
    #Gate.CentreOfCircle()[1]*Gate.CentreOfCircle()[3]))


if __name__=='__main__':
    rospy.init_node('cv_camera',anonymous=True, disable_signals=True)
    rospy.loginfo('init ...')

    Desired_Position_Gate = rospy.Publisher('/desired_position_gate',Float32MultiArray, queue_size=10)
    Desired_Position_Rotray = rospy.Publisher('/desired_position_rotray',Float32MultiArray, queue_size=10)
    
    subVideo = rospy.Subscriber('/tello/image_raw', Image , Init )
    
    rospy.spin()