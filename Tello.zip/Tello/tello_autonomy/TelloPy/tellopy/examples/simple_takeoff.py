from time import sleep
import tellopy
prev_flight_data = None
height = 0
def handler(event, sender, data, **args):
    drone = sender
    if event is drone.EVENT_FLIGHT_DATA:
        print(data)

def flightDataHandler(event, sender, data):
    #print('data= {}'.format(data))
    global prev_flight_data
    global height
    text = str(data)
    
    end = text.find('|',text.find('B')+4,text.find('W'))
    start = text.find('B')+4
    battrey = int(text[start:end])

    end1 = text.find('|',text.find('A'),text.find('S'))
    start1 = text.find('A')+4
    height = int(text[start1:end1])

    print'H : ' , height , 'BAT:' , battrey
    #print 'H : {0} BAT : {1}'.format(height,battrey)
    
    if prev_flight_data != text:
        prev_flight_data = text

def test():
    drone = tellopy.Tello()
    try:
        drone.subscribe(drone.EVENT_FLIGHT_DATA, handler)

        drone.connect()
        drone.wait_for_connection(60.0)
        drone.takeoff()
        drone.subscribe(drone.EVENT_FLIGHT_DATA, flightDataHandler)

        while True:
            e = 8 - height 
            kp = 0.02
            u = kp*e
            print(u)
            #drone.set_throttle(u)
            if abs(e) <= 1 :
                break
        drone.land()
    except Exception as ex:
        print(ex)
    finally:
        drone.land()
        drone.quit()

if __name__ == '__main__':
    test()
