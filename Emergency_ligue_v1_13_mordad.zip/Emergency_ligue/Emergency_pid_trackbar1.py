#!/usr/bin/env python

import cv2
import numpy as np

def nothing(x):
    pass

cv2.namedWindow('pid')
file_add = "pid.txt"
bar = ('P_yaw','I_yaw','D_yaw','P_pitch','I_pitch','D_pitch','P_X','I_X','D_X','P_Y','I_Y','D_Y')
ranges = []
try:
	fh = open(file_add, "r")
	val = fh.read()
	if(len(val)>0):
		val = val.split('\n')
		for i in range(len(bar)):
      			ranges.append(val[i].split(';')[1])
      			cv2.createTrackbar(bar[i], 'pid', 0, pow(10,2), nothing)
     			cv2.setTrackbarPos(bar[i], 'pid', int(val[i].split(';')[0]))
	fh.close()
except:
	pass
while(1):
    pid = []
    for i in range(len(bar)):
        pid.append(str(cv2.getTrackbarPos(bar[i],'pid'))+';'+ranges[i])
    f = open(file_add,"w")
    f.write('\n'.join(pid))
    f.close()
    cv2.waitKey(50)
