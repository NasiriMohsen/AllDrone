#!/usr/bin/env python

import cv2
import numpy as np

def nothing(x):
    pass

cv2.namedWindow('HSV_bar_Line')

bar = ('h_min','h_max','s_min','s_max','v_min','v_max','blockSize', 'C','similarity','morph')

for  i in range(8):
    cv2.createTrackbar(bar[i], 'HSV_bar_Line',0,255,nothing)
cv2.createTrackbar(bar[8], 'HSV_bar_Line',0,100,nothing)
cv2.createTrackbar(bar[9], 'HSV_bar_Line',0,1,nothing)

try:
	f = open("Emergency_Line_calibration.txt","r") 
	val = f.read()
	val = val.split('\n')
	if(len(val)>0):
		for i in range(len(bar)):
			cv2.setTrackbarPos(bar[i], 'HSV_bar_Line',int(val[i]))
	f.close()
except:
	pass
while(1):
    hsv = []
    for data in bar:
        hsv.append(str(cv2.getTrackbarPos(data,'HSV_bar_Line')))
    f = open("Emergency_Line_calibration.txt","w")
    f.write('\n'.join(hsv))
    f.close()
    cv2.waitKey(50)
