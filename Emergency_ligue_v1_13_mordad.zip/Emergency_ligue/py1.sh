#!/bin/bash
cd ~/ali_ros_projects/src/bebop/src/Emergency_ligue
python Emergency_pid_trackbar1.py & python Emergency_Line_tracbar1.py 

