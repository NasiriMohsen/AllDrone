#!/usr/bin/env python
import pyzbar.pyzbar as pyz
import cv2 as cv 
import rospy
import numpy as np 
from copy import deepcopy
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import CompressedImage

def Listwithoutrepeat(data,list = []):
    n = len(list)
    if (n == 0) or (n > 0 and list[n-1] != data):
        list.append(data)
    else:
        pass
    return list
###################################################
def qr_code(data):
    bridge=CvBridge()
    try:
    	frame=bridge.compressed_imgmsg_to_cv2(data,'bgr8')
    except CvBridgeError as e:
	print(e)
    black = np.zeros_like(frame)
    QRs = pyz.decode(frame)
    for QR in range (0,len(QRs)):
##################################################
        cords = QRs[QR].rect
        x,y,w,h = cords
        if x < 0:
            x = -x
        if y < 0:
            y = -y
        pointls = [0,0,0,0]
        polygon = QRs[QR].polygon
        for i in range (0,4):
            points = polygon[i]
            pointx = points[0]
            pointy = points[1]
            pointls[i] = (pointx,pointy)
            cv.circle(frame,(int(pointx),int(pointy)),4,(255,0,255),2)
##################################################
        QRframe = np.array([[pointls[0],pointls[1],pointls[2],pointls[3]]])
        cv.fillPoly(black,QRframe,(255,255,255))
        filtered = cv.bitwise_and(frame,black)
        frame = cv.addWeighted(frame,0.8,filtered,1,1)
##################################################
        name = str(deepcopy(QRs[QR].data))
        name = name.replace('b','', 1)
        name = name.replace("'",'')
        name = name.replace('"','')
        name = name.replace("http://",'')
 	name2 = name.split(',')
##################################################        
        allqrs = Listwithoutrepeat(name2)
        rect = QRs[QR].rect
        center = (int(rect.left+(rect.width/2)),int(rect.top+(rect.height/2)))
        cv.circle(frame,center,3,(0,255,255),3)
        print(QRs,center)
##################################################
    cv.imshow("window",frame)
    key = cv.waitKey(1)
    if ord("q")==key:
        cv.destroyAllWindows() 
    n = name2[-1]
    QRs = ['E,W,N,S,'+str(n)]
    if len(QRs) > 0:
        Qr = QRs[0]
        center = (1,1)
        foundqr = True
        if inmission == False:
            name = Qr.split(',')  
        if inmission == False and int(name[4]) == 0:
            path = name[mistogo[i]-1]                
            stopcenter(center)
            fallow(path)
            print(path)
            
        elif inmission == False and int(name[4]) == mistogo[i]:
            inmission = True
            print("in mission",mistogo[i])

        if inmission == True:
            Misnum = mistogo[i]
            if Misnum == 1:
                #go to the center of the + and drop the box and stop mision and i = i + 1 
                #Servo.Open()
                #sleep(1)
                #Servo.Close()
                print("M1")
                sleep(1)
                i = i + 1
                inmission = False
                pass

            elif Misnum == 2:
                #go to the tower and read qr take pic and open loop and stop mision and i = i + 1
                print("M2")
                sleep(1)
                i = i + 1
                inmission = False
                pass

            elif Misnum == 3:
                #go to victims find qrs and take pic stop mision and i = i + 1 
                print("M3")
                sleep(1)
                i = i + 1
                inmission = False
                pass

            elif Misnum == 4:
                print("M4")
                sleep(1)
                i = i + 1
                inmission = False
                pass
            
#######################################################
if __name__=='__main__':
	global name2
	name2=[]
	rospy.init_node("Emergency_qr")
	subvideo=rospy.Subscriber('/bebop/image_raw/compressed',CompressedImage,qr_code)
	rospy.spin()
	
