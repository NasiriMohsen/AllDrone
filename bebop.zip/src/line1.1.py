#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time
import numpy as np
import cv2

# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from drone_controller import BasicDroneController
from drone_video_display import DroneVideoDisplay

from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image
from bebop_msgs.msg import CommonCommonStateBatteryStateChanged as Batt
from geometry_msgs.msg import Twist

# Finally the GUI libraries
from PyQt5 import QtCore, QtGui, QtWidgets


# Here we define the keyboard map for our controller (note that python has no enums, so we use a class)
class KeyMapping(object):
	PitchForward     = QtCore.Qt.Key_W
	PitchBackward    = QtCore.Qt.Key_S
	RollLeft         = QtCore.Qt.Key_A
	RollRight        = QtCore.Qt.Key_D
	YawLeft          = QtCore.Qt.Key_Q
	YawRight         = QtCore.Qt.Key_E
	IncreaseAltitude = QtCore.Qt.Key_I
	DecreaseAltitude = QtCore.Qt.Key_K
	Takeoff          = QtCore.Qt.Key_T
	Land             = QtCore.Qt.Key_Space
	Emergency        = QtCore.Qt.Key_Enter
	StartStop        = QtCore.Qt.Key_O
	CameraUp	 = QtCore.Qt.Key_8
	CameraDown	 = QtCore.Qt.Key_2
	CameraDown	 = QtCore.Qt.Key_2
	CloseApp	 = QtCore.Qt.Key_Escape

# Our controller definition, note that we extend the DroneVideoDisplay class
class KeyboardController(DroneVideoDisplay):
	def __init__(self):
		super(KeyboardController,self).__init__()

		self.pubCamera = rospy.Publisher('/bebop/camera_control', Twist, queue_size=1)
		time.sleep(1)
		print('init ... ')
		self.cameraCommand = Twist()
		self.cameraCommand.angular.z = 0
		self.cameraCommand.angular.y = -83
		self.pubCamera.publish(self.cameraCommand)

		self.controller = BasicDroneController()

		self.bridge = CvBridge()
		self.sequence = [-0.03, 0.03, -0.03, 0.03]

		self.subVideo = rospy.Subscriber('/bebop/image_raw', Image, self.visionCycle)
		self.subBatt = rospy.Subscriber('/bebop/states/common/CommonState/BatteryStateChanged', Batt, self.battCheck)
		
		self.pitch = 0
		self.roll = 0
		self.yaw_velocity = 0 
		self.z_velocity = 0

		self.running = False
		self.row = 0
		self.counter = 51
		self.isHovering = False
		self.forwardCounter = 0
		self.sidewaysCounter = 0
		self.obstacleInSight = False
		self.oldObstacleInSight = False
		self.hoveringTimes = 0

# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
	def keyPressEvent(self, event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():
			# Handle the important cases first!
			if key == KeyMapping.Emergency:
				self.controller.SendEmergency()

			elif key == KeyMapping.CloseApp:
				self.controller.SendLand()
				cv2.destroyAllWindows()
				print ("BB")
				self.close()
			elif key == KeyMapping.CameraDown : 
				self.cameraCommand.angular.z = 0
				self.cameraCommand.angular.y += -5
				if self.cameraCommand.angular.y < -83:
					self.cameraCommand.angular.y = -83
				self.pubCamera.publish(self.cameraCommand)
			elif key == KeyMapping.CameraUp : 
				self.cameraCommand.angular.z = 0
				self.cameraCommand.angular.y += 5
				if self.cameraCommand.angular.y > 18:
					self.cameraCommand.angular.y = 18
				self.pubCamera.publish(self.cameraCommand)
			elif key == KeyMapping.Takeoff:
				self.controller.SendTakeoff()
			elif key == KeyMapping.Land:
				self.controller.SendLand()

			elif self.running is False and key == KeyMapping.StartStop :
				print('Starting ...')
				self.running = True
			elif key == KeyMapping.StartStop :
				print('Stopping ...')
				self.running = False

			else:
				# Now we handle moving, notice that this section is the opposite (+=) of the keyrelease section
				if key == KeyMapping.YawLeft:
					self.yaw_velocity += 0.3
				elif key == KeyMapping.YawRight:
					self.yaw_velocity += -0.3

				elif key == KeyMapping.PitchForward:
					self.pitch += 0.3
				elif key == KeyMapping.PitchBackward:
					self.pitch += -0.3

				elif key == KeyMapping.RollLeft:
					self.roll += 0.3
				elif key == KeyMapping.RollRight:
					self.roll += -0.3

				elif key == KeyMapping.IncreaseAltitude:
					self.z_velocity += 0.3
				elif key == KeyMapping.DecreaseAltitude:
					self.z_velocity += -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)


	def stopHovering(self, event):
		self.isHovering = False
		self.forwardCounter = 2
		self.sidewaysCounter = 2

	def visionCycle(self, data):
		try:
			cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
		except CvBridgeError as e:
			print(e)
		(rows,cols,channels) = cv_image.shape
		img = cv_image[:, :]
		buttom = img[rows-50:rows, :]
		top = img[0:50, :]
		left = img[:, 0:50]
		right = img[:, cols-50:cols]

		hsvButtom = cv2.cvtColor(buttom, cv2.COLOR_RGB2HSV)
		hsvTop = cv2.cvtColor(top, cv2.COLOR_RGB2HSV)
		hsvLeft = cv2.cvtColor(left, cv2.COLOR_RGB2HSV)
		hsvRight = cv2.cvtColor(right, cv2.COLOR_RGB2HSV)

		lower = np.array([0, 0, 0])
		upper = np.array([255 , 255, 50])

		maskB = cv2.inRange(hsvButtom, lower, upper)
		maskT = cv2.inRange(hsvTop, lower, upper)
		maskL = cv2.inRange(hsvLeft, lower, upper)
		maskR = cv2.inRange(hsvRight, lower, upper)

		imB, contoursB, hierarchyB = cv2.findContours(maskB, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		imT, contoursT, hierarchyT = cv2.findContours(maskT, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		imL, contoursL, hierarchyL = cv2.findContours(maskL, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		imR, contoursR, hierarchyR = cv2.findContours(maskR, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		

		maxContours = []
		maxContours.append( self.findMaxContour(contoursB,0) )
		maxContours.append( self.findMaxContour(contoursT,1) )
		maxContours.append( self.findMaxContour(contoursL,2) )
		maxContours.append( self.findMaxContour(contoursR,3) )

		maxContours[0][1] += rows-50 			# shifting y to match camera frame
		maxContours[3][0] += cols-50			# shifting x to match camera frame

		maxNum = -1
		maxArea = 0
		drawLine = False

		print (maxContours)
		print (np.array(maxContours))

		borderContours = np.array(maxContours)
		borderContours.view('i4,i4,i4,i4').sort(order=['f2'], axis =0)
		print (borderContours)

		for i in range(0,4):
			if maxContours[i][2] > maxArea :
				maxArea = maxContours[i][2]
				maxNum = i
		
		if maxNum != -1 :
			firstContour = maxContours[maxNum]
			maxContours.pop(maxNum)

			maxArea = 0
			maxNum = -1
			for i in range(0,3):
				if maxContours[i][2] > maxArea :
					maxArea = maxContours[i][2]
					maxNum = i

			if maxNum != -1 :
				secondContour = maxContours[maxNum]
				drawLine = True
				print (maxArea)


		if drawLine :
			cv2.line(img, (firstContour[0], firstContour[1]), (secondContour[0], secondContour[1]), (255, 0, 0), 5)
			lineDeviation = (float((firstContour[0]+secondContour[0])/2)- cols/2) * -0.001   #deviation from center line
			lineAngle = np.arctan(float(firstContour[0]-secondContour[0]) / float(firstContour[1]-secondContour[1]))
			print("line deviation is: " + str(lineDeviation))
			self.correctYaw(lineAngle, lineDeviation)


		cv2.imshow('top', maskT)
		cv2.imshow('buttom', maskB)
		cv2.imshow('left', maskL)
		cv2.imshow('right', maskR)

		cv2.imshow('line image', img)

	

	def battCheck ( self , Bdata):
		print(Bdata)



	def findMaxContour(self, contours,id):
		if len(contours) > 0 :
			cnt = max(contours, key = cv2.contourArea)
			M = cv2.moments(cnt)
			if M['m00'] != 0:
				cx = int(M['m10']/M['m00'])
				cy = int(M['m01']/M['m00'])
				return [cx, cy, cv2.contourArea(cnt),id]
			else :
				return [0, 0, 0,-1]
				
		else :
			return [0, 0, 0,-1]

	def correctYaw(self, lineAngle, lineDeviation):
		if self.running is True :
			if lineAngle < 0.1 and lineAngle > -0.1:
				lineAngle = 0

			if lineDeviation > 0.2 :
				lineDeviation = 0.2
			if lineDeviation < -0.2 :
				lineDeviation = -0.2
			if lineDeviation < 0.05 and lineDeviation> 0.05 :
				lineDeviation = 0;	

			self.controller.SetCommand(lineDeviation * 0.5, 0.10, lineAngle, 0)
			


	def keyReleaseEvent(self,event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():
			# Note that we don't handle the release of emergency/takeoff/landing keys here, there is no need.
			# Now we handle moving, notice that this section is the opposite (-=) of the keypress section
			if key == KeyMapping.YawLeft:
				self.yaw_velocity -= 0.3
			elif key == KeyMapping.YawRight:
				self.yaw_velocity -= -0.3

			elif key == KeyMapping.PitchForward:
				self.pitch -= 0.3
			elif key == KeyMapping.PitchBackward:
				self.pitch -= -0.3

			elif key == KeyMapping.RollLeft:
				self.roll -= 0.3
			elif key == KeyMapping.RollRight:
				self.roll -= -0.3

			elif key == KeyMapping.IncreaseAltitude:
				self.z_velocity -= 0.3
			elif key == KeyMapping.DecreaseAltitude:
				self.z_velocity -= -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)



# Setup the application
if __name__=='__main__':
	import sys
	# Firstly we setup a ros node, so that we can communicate with the other packages
	rospy.init_node('bebop_keyboard_controller')

	# Now we construct our Qt Application and associated controllers and windows
	app = QtWidgets.QApplication(sys.argv)
	display = KeyboardController()

	display.show()

	# executes the QT application
	status = app.exec_()

	# Doesn't get here!?
	# and only progresses to here once the application has been shutdown
	rospy.signal_shutdown('Great Flying!')

	sys.exit(status)
