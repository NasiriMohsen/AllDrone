#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import time

from PyQt5 import QtCore, QtGui, QtWidgets
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image
from drone_controller import BasicDroneController
from drone_video_display import DroneVideoDisplay
from keyboard_controller import KeyboardController

class KeyMapping(object):
	StartStop     = QtCore.Qt.Key_Return

class ObstacleAvoidanceController(QtWidgets.QMainWindow):

	def __init__(self):
		# Construct the parent class
		super(ObstacleAvoidanceController, self).__init__()

		self.controller = BasicDroneController()
		self.bridge = CvBridge()
		self.sequence = [-0.1, 0.1, -0.1, 0.1]

		#self.subVideo = rospy.Subscriber('/bebop/image_raw', Image, self.controlCycle)

		#Flags
		self.running = False
		self.row = 0
		self.counter = 51
		self.isHovering = False
		self.forwardCounter = 0
		self.sidewaysCounter = 0
		self.obstacleInSight = False
		self.oldObstacleInSight = False
		self.hoveringTimes = 0
		

	def keyPressEvent(self, event) :
		key = event.key()
		if self.controller is not None and self.running is False and key == KeyMapping.StartStop :
			print('Starting ...')
			self.running = True
		elif key == KeyMapping.StartStop :
			print('Stopping ...')
			self.running = False


	def stopHovering(self, event):
		self.isHovering = False
		self.forwardCounter = 2
		self.sidewaysCounter = 2

	def controlCycle(self, data):
		try:
			cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
		except CvBridgeError as e:
			print(e)
		(rows,cols,channels) = cv_image.shape
		img = cv_image[440:rows, 100:cols-100]

		hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
		lower = np.array([78,51,113])
		upper = np.array([112,238,233])
		mask = cv2.inRange(hsv, lower, upper)
		res = cv2.bitwise_and(img, img, mask= mask)

		grayImage = cv2.cvtColor(res, cv2.COLOR_RGB2GRAY)

		ret, th = cv2.threshold(grayImage, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)

		im2, contours, hierarchy = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		eh = cv2.drawContours(res, contours, -1, (0,255,0), 3)

		goodCnts = 0
		for cnt in contours :
			area = cv2.contourArea(cnt)
			if area > 80 :
				self.counter = 0
				goodCnts += 1

		self.oldObstacleInSight = self.obstacleInSight
		if goodCnts > 0 :
			self.obstacleInSight = True
		else :
			self.counter += 1
			if self.counter > 50 :
				self.obstacleInSight = False
			else :
				self.obstacleInSight = True

		cv2.imshow('res',eh)
		#cv2.waitKey(33)

		if self.running is True :
			if self.oldObstacleInSight != self.obstacleInSight :
				self.hoveringTimes += 1
				print('Hovering ...')
				self.controller.SetCommand(0, 0, 0, 0)
				self.isHovering = True
				if self.hoveringTimes % 2 == 0 :
					self.row += 1
					print('***** row changed ******')
				rospy.Timer(rospy.Duration(3), self.stopHovering)
			elif self.obstacleInSight is False and self.isHovering is False : 
				print('Moving forward ...')
				self.controller.SetCommand(0, 0.03, 0, 0)
			elif self.obstacleInSight is True and self.isHovering is False :
				print('Moving sideways ...')
				self.controller.SetCommand(self.sequence[self.row], 0, 0, 0)



# Setup the application
if __name__=='__main__':
	import sys
	rospy.init_node('bebop_obstacle_avoidance')

	app = QtWidgets.QApplication(sys.argv)

	camDisplay = KeyboardController()
	camDisplay.show()

	controlDisplay = ObstacleAvoidanceController()
	controlDisplay.show()

	status = app.exec_()

	rospy.signal_shutdown('Great Flying!')
	sys.exit(status)